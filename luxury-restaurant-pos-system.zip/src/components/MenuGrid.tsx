import { useState } from 'react';
import { Search, Flame, Plus } from 'lucide-react';
import { MenuItem, OrderItem } from '../types';
import { menuItems, categories } from '../data/menu';

interface MenuGridProps {
  selectedCategory: string;
  orderItems: OrderItem[];
  onAddItem: (item: OrderItem) => void;
}

export default function MenuGrid({ selectedCategory, orderItems, onAddItem }: MenuGridProps) {
  const [search, setSearch] = useState('');
  const [sizeModal, setSizeModal] = useState<MenuItem | null>(null);

  const filteredItems = menuItems.filter(item => {
    const matchCategory = selectedCategory === 'all' || item.cat === selectedCategory;
    const matchSearch = search === '' || item.name.toLowerCase().includes(search.toLowerCase());
    return matchCategory && matchSearch;
  });

  const catLabel = categories.find(c => c.id === selectedCategory)?.name || 'All Items';
  const catIcon = categories.find(c => c.id === selectedCategory)?.icon || '🍽️';

  const getItemQty = (sku: string, size?: string) => {
    const key = sku + (size || '');
    const item = orderItems.find(i => i.sku + (i.size || '') === key);
    return item?.qty || 0;
  };

  const handleAddItem = (menuItem: MenuItem) => {
    if (menuItem.sizes && menuItem.sizes.length > 0) {
      setSizeModal(menuItem);
    } else {
      onAddItem({ sku: menuItem.sku, name: menuItem.name, price: menuItem.price, qty: 1 });
    }
  };

  const handleSizeSelect = (menuItem: MenuItem, size: { name: string; price: number }) => {
    onAddItem({
      sku: menuItem.sku,
      name: `${menuItem.name} (${size.name})`,
      price: size.price,
      qty: 1,
      size: size.name,
    });
    setSizeModal(null);
  };

  const heatColors: Record<string, string> = {
    None: 'text-navy-400',
    Mild: 'text-yellow-400',
    Medium: 'text-orange-400',
    Hot: 'text-red-400',
  };

  return (
    <div className="flex-1 flex flex-col min-h-0 p-3 lg:p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-3 flex-shrink-0">
        <div className="flex items-center gap-2">
          <span className="text-xl">{catIcon}</span>
          <h2 className="text-base lg:text-lg font-playfair font-bold text-cream-100">{catLabel}</h2>
          <span className="text-xs font-mono text-navy-300 glass-light px-2 py-0.5 rounded-full">
            {filteredItems.length}
          </span>
        </div>

        {/* Search */}
        <div className="relative w-48 lg:w-64">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search menu..."
            className="w-full pl-8 pr-3 py-2 rounded-xl bg-navy-800/60 border border-navy-600/30
            text-sm font-dm text-cream-200 placeholder:text-navy-400
            focus:outline-none focus:border-gold-500/40 focus:bg-navy-800
            transition-all duration-300"
          />
        </div>
      </div>

      {/* Grid */}
      <div className="flex-1 overflow-y-auto">
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-2.5">
          {filteredItems.map(item => {
            const qty = getItemQty(item.sku);
            return (
              <button
                key={item.sku}
                onClick={() => handleAddItem(item)}
                className="group relative glass-light rounded-2xl p-3 text-left
                hover:border-gold-500/30 transition-all duration-300
                hover:-translate-y-0.5 hover:shadow-lg hover:shadow-gold-900/10
                overflow-hidden"
              >
                {/* Gold top border on hover */}
                <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-gold-400 to-transparent
                  opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                {/* Category tag */}
                <div className="text-[9px] uppercase tracking-widest text-navy-400 font-dm mb-1">
                  {item.cat}
                </div>

                {/* Name */}
                <h3 className="text-sm font-dm font-semibold text-cream-100 group-hover:text-gold-300 transition-colors mb-1.5 leading-tight line-clamp-2">
                  {item.name}
                </h3>

                {/* Heat & Cal */}
                <div className="flex items-center gap-2 mb-2">
                  {item.heat !== 'None' && (
                    <div className={`flex items-center gap-0.5 text-[10px] font-dm ${heatColors[item.heat]}`}>
                      <Flame size={10} />
                      <span>{item.heat}</span>
                    </div>
                  )}
                  <span className="text-[10px] text-navy-400">{item.cal} cal</span>
                </div>

                {/* Price */}
                <div className="flex items-center justify-between">
                  <span className="font-mono text-sm font-bold text-gold-400">
                    Rs {item.price}
                  </span>
                  {item.sizes && (
                    <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-blue-900/40 text-blue-300 border border-blue-700/30">
                      SIZES
                    </span>
                  )}
                </div>

                {/* Qty badge */}
                {qty > 0 && (
                  <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-gold-500 text-navy-900 text-xs font-mono font-bold flex items-center justify-center shadow-lg">
                    {qty}
                  </div>
                )}

                {/* Add icon */}
                <div className="absolute bottom-2 right-2 w-7 h-7 rounded-full bg-gold-600/20 border border-gold-500/20
                  flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300
                  group-hover:bg-gold-600/30">
                  <Plus size={14} className="text-gold-400" />
                </div>
              </button>
            );
          })}
        </div>

        {filteredItems.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="text-4xl mb-3">🍽️</div>
            <p className="text-navy-400 font-dm text-sm">No items found</p>
          </div>
        )}
      </div>

      {/* Size Modal */}
      {sizeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm" onClick={() => setSizeModal(null)}>
          <div className="glass rounded-2xl p-6 max-w-sm w-full mx-4 animate-slide-up" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-playfair font-bold text-cream-100 mb-1">{sizeModal.name}</h3>
            <p className="text-xs text-navy-300 mb-4">Select a size</p>
            <div className="space-y-2">
              {sizeModal.sizes!.map(size => (
                <button
                  key={size.name}
                  onClick={() => handleSizeSelect(sizeModal, size)}
                  className="w-full flex items-center justify-between p-3 rounded-xl glass-light
                  hover:border-gold-500/30 transition-all duration-300 group"
                >
                  <span className="text-sm font-dm text-cream-200 group-hover:text-gold-300">{size.name}</span>
                  <span className="font-mono text-sm font-bold text-gold-400">Rs {size.price}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
