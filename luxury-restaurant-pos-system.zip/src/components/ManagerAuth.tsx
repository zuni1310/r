import { useState } from 'react';
import { Shield, AlertCircle } from 'lucide-react';

interface ManagerAuthProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  title?: string;
}

const MANAGER_KEY = 'OPTIPLEX760';

export default function ManagerAuth({ isOpen, onClose, onSuccess, title = 'Manager Authorization Required' }: ManagerAuthProps) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const [shake, setShake] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = () => {
    if (pin === MANAGER_KEY) {
      setPin('');
      setError(false);
      onSuccess();
    } else {
      setError(true);
      setShake(true);
      setTimeout(() => setShake(false), 500);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={onClose}>
      <div
        className={`glass rounded-3xl max-w-sm w-full overflow-hidden animate-slide-up premium-shadow
        ${shake ? 'animate-[shake_0.5s_ease-in-out]' : ''}`}
        onClick={e => e.stopPropagation()}
        style={shake ? { animation: 'shake 0.5s ease-in-out' } : {}}
      >
        <div className="p-6 text-center">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-maroon-600/30 to-maroon-800/30 border border-maroon-500/30 flex items-center justify-center mx-auto mb-4">
            <Shield size={28} className="text-maroon-400" />
          </div>

          <h2 className="text-lg font-playfair font-bold text-cream-100 mb-1">{title}</h2>
          <p className="text-xs text-navy-300 font-dm mb-5">Enter manager key to proceed</p>

          {error && (
            <div className="flex items-center gap-2 justify-center mb-3 text-red-400 text-xs font-dm">
              <AlertCircle size={14} />
              <span>Invalid key. Try again.</span>
            </div>
          )}

          <input
            type="password"
            value={pin}
            onChange={e => { setPin(e.target.value); setError(false); }}
            onKeyDown={e => e.key === 'Enter' && handleSubmit()}
            placeholder="Enter Manager Key"
            className="w-full px-4 py-3 rounded-xl bg-navy-800/60 border border-navy-600/30
            text-center text-lg font-mono text-cream-200 placeholder:text-navy-500
            focus:outline-none focus:border-gold-500/40 transition-all tracking-[0.3em]"
            autoFocus
          />

          <div className="flex gap-2 mt-5">
            <button
              onClick={onClose}
              className="flex-1 py-3 rounded-xl glass-light text-sm font-dm text-navy-300 hover:text-cream-200 transition-all"
            >
              Cancel
            </button>
            <button
              onClick={handleSubmit}
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-maroon-600 to-maroon-700 text-white text-sm font-playfair font-bold
              hover:from-maroon-500 hover:to-maroon-600 transition-all duration-300 shadow-lg shadow-maroon-900/30"
            >
              Authorize
            </button>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
          20%, 40%, 60%, 80% { transform: translateX(5px); }
        }
      `}</style>
    </div>
  );
}
