import { X } from 'lucide-react';
import { TableState, OrderType } from '../types';
import { categories } from '../data/menu';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  tables: TableState[];
  selectedTable: number | null;
  onSelectTable: (id: number) => void;
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
  orderType: OrderType;
}

export default function Sidebar({
  isOpen, onClose, tables, selectedTable, onSelectTable,
  selectedCategory, onSelectCategory, orderType
}: SidebarProps) {
  const tableStatusColors: Record<string, string> = {
    empty: 'bg-navy-700/60 border-navy-500/30 hover:border-gold-500/40 text-navy-200',
    occupied: 'bg-maroon-900/50 border-maroon-600/50 text-maroon-200',
    active: 'bg-gradient-to-br from-navy-600 to-navy-700 border-gold-500/60 text-gold-300 gold-glow',
  };

  const showTables = orderType === 'dine-in';

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`fixed lg:relative top-0 left-0 h-full w-64 lg:w-56 xl:w-60 z-40 lg:z-0 glass premium-shadow
        transition-transform duration-300 ease-out flex flex-col
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        pt-16 lg:pt-0`}
        style={{ borderRight: '1px solid rgba(212,168,40,0.12)' }}
      >
        {/* Close btn mobile */}
        <button
          onClick={onClose}
          className="lg:hidden absolute top-3 right-3 p-1.5 rounded-lg hover:bg-navy-700 text-navy-300 z-50"
        >
          <X size={18} />
        </button>

        <div className="flex-1 overflow-y-auto p-3 space-y-4">
          {/* Tables */}
          <div>
            <h3 className="text-xs font-playfair font-semibold text-gold-400 uppercase tracking-wider mb-2">
              Table Management
            </h3>

            {showTables ? (
              <div className="grid grid-cols-2 gap-1.5">
                {tables.map(table => (
                  <button
                    key={table.id}
                    onClick={() => onSelectTable(table.id)}
                    className={`relative p-2.5 rounded-xl border text-xs font-dm font-medium
                    transition-all duration-300 text-center
                    ${selectedTable === table.id
                      ? 'bg-gradient-to-br from-gold-600/30 to-gold-700/20 border-gold-400/60 text-gold-300 gold-glow'
                      : tableStatusColors[table.status]
                    }`}
                  >
                    <div className="text-[10px] uppercase tracking-wider opacity-70 mb-0.5">Table</div>
                    <div className="font-mono text-base font-bold">{table.id}</div>
                    <div className={`mt-1 text-[8px] uppercase tracking-widest px-1.5 py-0.5 rounded-full inline-block
                      ${table.status === 'empty' ? 'bg-navy-600/50 text-navy-300' :
                        table.status === 'occupied' ? 'bg-maroon-700/50 text-maroon-300' :
                        'bg-gold-700/30 text-gold-300'}`}>
                      {table.status}
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="glass-light rounded-xl p-3 text-center">
                <div className="text-2xl mb-1">{orderType === 'package' ? '📦' : '🛵'}</div>
                <p className="text-[11px] text-navy-300 font-dm">
                  No table required for<br />
                  <span className="text-gold-400 font-semibold capitalize">{orderType}</span> orders
                </p>
              </div>
            )}
          </div>

          {/* Categories */}
          <div>
            <h3 className="text-xs font-playfair font-semibold text-gold-400 uppercase tracking-wider mb-2">
              Categories
            </h3>
            <div className="space-y-0.5">
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => { onSelectCategory(cat.id); onClose(); }}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm font-dm
                  transition-all duration-300
                  ${selectedCategory === cat.id
                    ? 'bg-gradient-to-r from-gold-600/20 to-transparent border-l-2 border-gold-400 text-gold-300'
                    : 'text-navy-200 hover:bg-navy-700/50 hover:text-cream-200 border-l-2 border-transparent'
                  }`}
                >
                  <span className="text-base">{cat.icon}</span>
                  <span>{cat.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
