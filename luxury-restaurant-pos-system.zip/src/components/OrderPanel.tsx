import { useState } from 'react';
import {
  X, Plus, Minus, ShoppingBag, Trash2, CreditCard, Banknote,
  UtensilsCrossed, Package, Truck, Percent, DollarSign
} from 'lucide-react';
import { OrderItem, OrderType, PaymentMethod } from '../types';

interface OrderPanelProps {
  isOpen: boolean;
  onClose: () => void;
  items: OrderItem[];
  orderType: OrderType;
  setOrderType: (t: OrderType) => void;
  selectedTable: number | null;
  paymentMethod: PaymentMethod;
  setPaymentMethod: (m: PaymentMethod) => void;
  discountValue: number;
  setDiscountValue: (v: number) => void;
  discountType: 'percent' | 'flat';
  setDiscountType: (t: 'percent' | 'flat') => void;
  bagQty: number;
  setBagQty: (q: number) => void;
  bagCost: number;
  subtotal: number;
  bagTotal: number;
  discountAmount: number;
  tax: number;
  grandTotal: number;
  onUpdateQty: (sku: string, size: string | undefined, delta: number) => void;
  onRemoveItem: (sku: string, size: string | undefined) => void;
  onClearOrder: () => void;
  onCharge: () => void;
}

export default function OrderPanel({
  isOpen, onClose, items, orderType, setOrderType,
  selectedTable, paymentMethod, setPaymentMethod,
  discountValue, setDiscountValue, discountType, setDiscountType,
  bagQty, setBagQty, bagCost,
  subtotal, bagTotal, discountAmount, tax, grandTotal,
  onUpdateQty, onRemoveItem, onClearOrder, onCharge
}: OrderPanelProps) {
  const [showDiscount, setShowDiscount] = useState(false);

  const orderTypeOpts: { key: OrderType; label: string; icon: React.ReactNode }[] = [
    { key: 'dine-in', label: 'Dine-In', icon: <UtensilsCrossed size={14} /> },
    { key: 'package', label: 'Package', icon: <Package size={14} /> },
    { key: 'dispatch', label: 'Dispatch', icon: <Truck size={14} /> },
  ];

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`fixed lg:relative top-0 right-0 h-full w-80 lg:w-72 xl:w-80 z-40 lg:z-0
        glass premium-shadow transition-transform duration-300 ease-out flex flex-col
        ${isOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}
        pt-14 lg:pt-0`}
        style={{ borderLeft: '1px solid rgba(212,168,40,0.12)' }}
      >
        {/* Header */}
        <div className="flex-shrink-0 p-3 border-b border-navy-700/50">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h2 className="text-sm font-playfair font-bold text-cream-100">Current Order</h2>
              {selectedTable && orderType === 'dine-in' && (
                <span className="text-[10px] font-mono text-gold-400">Table {selectedTable}</span>
              )}
            </div>
            <div className="flex items-center gap-1">
              {items.length > 0 && (
                <button onClick={onClearOrder} className="p-1.5 rounded-lg hover:bg-red-900/30 text-red-400 transition-all">
                  <Trash2 size={14} />
                </button>
              )}
              <button onClick={onClose} className="lg:hidden p-1.5 rounded-lg hover:bg-navy-700 text-navy-300">
                <X size={16} />
              </button>
            </div>
          </div>

          {/* Order Type */}
          <div className="flex gap-1 p-0.5 rounded-xl bg-navy-800/60">
            {orderTypeOpts.map(opt => (
              <button
                key={opt.key}
                onClick={() => setOrderType(opt.key)}
                className={`flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg text-[11px] font-dm font-medium transition-all duration-300
                ${orderType === opt.key
                  ? 'bg-gradient-to-r from-gold-600/30 to-gold-700/20 text-gold-300 shadow-sm'
                  : 'text-navy-300 hover:text-cream-200'
                }`}
              >
                {opt.icon}
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Items list */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1.5">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12">
              <div className="w-16 h-16 rounded-full glass-light flex items-center justify-center mb-3">
                <ShoppingBag size={24} className="text-navy-400" />
              </div>
              <p className="text-sm text-navy-400 font-dm">No items added</p>
              <p className="text-xs text-navy-500 font-dm mt-1">Tap items to add</p>
            </div>
          ) : (
            items.map(item => {
              const key = item.sku + (item.size || '');
              return (
                <div key={key} className="glass-light rounded-xl p-2.5 animate-fade-in group">
                  <div className="flex items-start justify-between mb-1.5">
                    <div className="flex-1 mr-2">
                      <p className="text-xs font-dm font-semibold text-cream-200 leading-tight">{item.name}</p>
                      <p className="text-[10px] font-mono text-navy-400 mt-0.5">Rs {item.price} each</p>
                    </div>
                    <button
                      onClick={() => onRemoveItem(item.sku, item.size)}
                      className="p-1 rounded-md hover:bg-red-900/30 text-navy-500 hover:text-red-400 transition-all opacity-0 group-hover:opacity-100"
                    >
                      <X size={12} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onUpdateQty(item.sku, item.size, -1)}
                        className="w-6 h-6 rounded-lg bg-navy-700/60 border border-navy-600/30 flex items-center justify-center
                        hover:border-red-500/40 hover:bg-red-900/20 text-navy-300 hover:text-red-400 transition-all"
                      >
                        <Minus size={11} />
                      </button>
                      <span className="w-8 text-center font-mono text-sm font-bold text-cream-100">{item.qty}</span>
                      <button
                        onClick={() => onUpdateQty(item.sku, item.size, 1)}
                        className="w-6 h-6 rounded-lg bg-navy-700/60 border border-navy-600/30 flex items-center justify-center
                        hover:border-gold-500/40 hover:bg-gold-900/20 text-navy-300 hover:text-gold-400 transition-all"
                      >
                        <Plus size={11} />
                      </button>
                    </div>
                    <span className="font-mono text-sm font-bold text-gold-400">
                      Rs {(item.price * item.qty).toLocaleString()}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="flex-shrink-0 p-3 space-y-2 border-t border-navy-700/50">
          {/* Bag Controls */}
          <div className="flex items-center justify-between glass-light rounded-xl p-2">
            <div className="flex items-center gap-1.5">
              <ShoppingBag size={13} className="text-gold-400" />
              <span className="text-[11px] font-dm text-navy-300">Bags (Rs {bagCost}/ea)</span>
            </div>
            <div className="flex items-center gap-1">
              <button onClick={() => setBagQty(Math.max(0, bagQty - 1))} className="w-5 h-5 rounded bg-navy-700 flex items-center justify-center text-navy-300 hover:text-cream-200 transition-all">
                <Minus size={10} />
              </button>
              <span className="w-6 text-center font-mono text-xs font-bold text-cream-200">{bagQty}</span>
              <button onClick={() => setBagQty(bagQty + 1)} className="w-5 h-5 rounded bg-navy-700 flex items-center justify-center text-navy-300 hover:text-cream-200 transition-all">
                <Plus size={10} />
              </button>
            </div>
          </div>

          {/* Discount Toggle */}
          <button
            onClick={() => setShowDiscount(!showDiscount)}
            className="w-full flex items-center justify-between glass-light rounded-xl p-2 hover:border-gold-500/20 transition-all"
          >
            <div className="flex items-center gap-1.5">
              <Percent size={13} className="text-gold-400" />
              <span className="text-[11px] font-dm text-navy-300">Discount</span>
            </div>
            {discountValue > 0 && (
              <span className="text-[11px] font-mono text-green-400">
                -{discountType === 'percent' ? `${discountValue}%` : `Rs ${discountValue}`}
              </span>
            )}
          </button>

          {showDiscount && (
            <div className="glass-light rounded-xl p-2.5 space-y-2 animate-fade-in">
              <div className="flex gap-1">
                <button
                  onClick={() => setDiscountType('percent')}
                  className={`flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg text-[11px] font-dm transition-all
                  ${discountType === 'percent' ? 'bg-gold-600/20 text-gold-300' : 'text-navy-400 hover:text-cream-200'}`}
                >
                  <Percent size={11} /> Percent
                </button>
                <button
                  onClick={() => setDiscountType('flat')}
                  className={`flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg text-[11px] font-dm transition-all
                  ${discountType === 'flat' ? 'bg-gold-600/20 text-gold-300' : 'text-navy-400 hover:text-cream-200'}`}
                >
                  <DollarSign size={11} /> Flat (Rs)
                </button>
              </div>
              <input
                type="number"
                value={discountValue || ''}
                onChange={e => setDiscountValue(Number(e.target.value))}
                placeholder={discountType === 'percent' ? 'Enter %' : 'Enter amount'}
                className="w-full px-3 py-1.5 rounded-lg bg-navy-800/60 border border-navy-600/30
                text-sm font-mono text-cream-200 placeholder:text-navy-500
                focus:outline-none focus:border-gold-500/40 transition-all"
              />
            </div>
          )}

          {/* Payment Method */}
          <div className="flex gap-1">
            <button
              onClick={() => setPaymentMethod('cash')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-dm font-medium transition-all duration-300
              ${paymentMethod === 'cash'
                ? 'bg-green-900/30 border border-green-500/40 text-green-400'
                : 'glass-light text-navy-300 hover:text-cream-200'
              }`}
            >
              <Banknote size={14} /> Cash
            </button>
            <button
              onClick={() => setPaymentMethod('card')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-dm font-medium transition-all duration-300
              ${paymentMethod === 'card'
                ? 'bg-blue-900/30 border border-blue-500/40 text-blue-400'
                : 'glass-light text-navy-300 hover:text-cream-200'
              }`}
            >
              <CreditCard size={14} /> Card
            </button>
          </div>

          {/* Totals */}
          <div className="space-y-1 text-xs font-dm">
            <div className="flex justify-between text-navy-300">
              <span>Subtotal</span>
              <span className="font-mono">Rs {subtotal.toLocaleString()}</span>
            </div>
            {bagTotal > 0 && (
              <div className="flex justify-between text-navy-300">
                <span>Bags ({bagQty}x)</span>
                <span className="font-mono">Rs {bagTotal.toLocaleString()}</span>
              </div>
            )}
            {discountAmount > 0 && (
              <div className="flex justify-between text-green-400">
                <span>Discount</span>
                <span className="font-mono">-Rs {Math.round(discountAmount).toLocaleString()}</span>
              </div>
            )}
            <div className="flex justify-between text-navy-300">
              <span>Tax (13%)</span>
              <span className="font-mono">Rs {tax.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-cream-100 font-bold text-sm pt-1 border-t border-navy-700/50">
              <span>Total</span>
              <span className="font-mono text-gold-400">Rs {grandTotal.toLocaleString()}</span>
            </div>
          </div>

          {/* Charge Button */}
          <button
            onClick={onCharge}
            disabled={items.length === 0}
            className={`w-full py-3 rounded-2xl text-sm font-playfair font-bold tracking-wide
            transition-all duration-300 ${
              items.length === 0
                ? 'bg-navy-700/50 text-navy-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-gold-500 to-gold-600 text-navy-900 hover:from-gold-400 hover:to-gold-500 hover:shadow-lg hover:shadow-gold-500/20 active:scale-[0.98]'
            }`}
          >
            {items.length === 0 ? 'ADD ITEMS TO CHARGE' : `💰 CHARGE Rs ${grandTotal.toLocaleString()}`}
          </button>
        </div>
      </aside>
    </>
  );
}
