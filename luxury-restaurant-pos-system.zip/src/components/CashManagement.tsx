import { useState } from 'react';
import { X, Lock, Unlock, DollarSign, TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react';
import { CashTally } from '../types';

interface CashManagementProps {
  isOpen: boolean;
  onClose: () => void;
  cashTally: CashTally;
  onSetOpening: (amount: number) => void;
  onSetClosing: (amount: number) => void;
  onRequestUnlock: () => void;
  todayRevenue: number;
}

export default function CashManagement({
  isOpen, onClose, cashTally, onSetOpening, onSetClosing, onRequestUnlock, todayRevenue
}: CashManagementProps) {
  const [openingInput, setOpeningInput] = useState('');
  const [closingInput, setClosingInput] = useState('');

  if (!isOpen) return null;

  const isLocked = !!cashTally.lockedAt;
  const lockAge = cashTally.lockedAt
    ? (Date.now() - new Date(cashTally.lockedAt).getTime()) / (1000 * 60 * 60)
    : 0;
  const canUnlock = lockAge >= 20;

  const expectedCash = cashTally.openingCash + todayRevenue;
  const difference = cashTally.closingCash > 0 ? cashTally.closingCash - expectedCash : 0;

  const handleSaveOpening = () => {
    const amt = Number(openingInput);
    if (amt >= 0) {
      onSetOpening(amt);
      setOpeningInput('');
    }
  };

  const handleSaveClosing = () => {
    const amt = Number(closingInput);
    if (amt >= 0) {
      onSetClosing(amt);
      setClosingInput('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="glass rounded-3xl max-w-lg w-full max-h-[90vh] overflow-y-auto animate-slide-up premium-shadow" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-5 border-b border-navy-700/50">
          <div>
            <h2 className="text-lg font-playfair font-bold text-cream-100">Cash Management</h2>
            <p className="text-xs text-navy-300 font-dm">Daily cash tracking & tally</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-navy-700 text-navy-300 transition-all">
            <X size={18} />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Opening Cash */}
          <div className="glass-light rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-green-900/30 flex items-center justify-center">
                  <DollarSign size={16} className="text-green-400" />
                </div>
                <div>
                  <h3 className="text-sm font-dm font-semibold text-cream-100">Opening Cash</h3>
                  <p className="text-[10px] text-navy-400 font-dm">Start of day balance</p>
                </div>
              </div>
              {isLocked && (
                <div className="flex items-center gap-1.5">
                  <Lock size={12} className="text-maroon-400" />
                  <span className="text-[10px] text-maroon-400 font-dm">Locked</span>
                </div>
              )}
            </div>

            {isLocked ? (
              <div className="flex items-center justify-between">
                <span className="font-mono text-xl font-bold text-green-400">Rs {cashTally.openingCash.toLocaleString()}</span>
                <button
                  onClick={() => {
                    if (canUnlock) {
                      onRequestUnlock();
                    }
                  }}
                  disabled={!canUnlock}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-dm transition-all
                  ${canUnlock
                    ? 'bg-maroon-600/20 text-maroon-300 hover:bg-maroon-600/30'
                    : 'bg-navy-700/50 text-navy-500 cursor-not-allowed'
                  }`}
                >
                  <Unlock size={12} />
                  {canUnlock ? 'Unlock' : `${Math.ceil(20 - lockAge)}h left`}
                </button>
              </div>
            ) : (
              <div className="flex gap-2">
                <input
                  type="number"
                  value={openingInput}
                  onChange={e => setOpeningInput(e.target.value)}
                  placeholder="Enter opening cash"
                  className="flex-1 px-3 py-2 rounded-xl bg-navy-800/60 border border-navy-600/30
                  text-sm font-mono text-cream-200 placeholder:text-navy-500
                  focus:outline-none focus:border-gold-500/40 transition-all"
                />
                <button
                  onClick={handleSaveOpening}
                  className="px-4 py-2 rounded-xl bg-green-600/20 border border-green-500/30 text-green-400 text-xs font-dm font-semibold hover:bg-green-600/30 transition-all"
                >
                  Save & Lock
                </button>
              </div>
            )}
          </div>

          {/* Today's Stats */}
          <div className="grid grid-cols-2 gap-3">
            <div className="glass-light rounded-xl p-3 text-center">
              <div className="text-[10px] text-navy-400 font-dm mb-1">Sales Cash</div>
              <div className="font-mono text-lg font-bold text-blue-400">Rs {todayRevenue.toLocaleString()}</div>
            </div>
            <div className="glass-light rounded-xl p-3 text-center">
              <div className="text-[10px] text-navy-400 font-dm mb-1">Expected Cash</div>
              <div className="font-mono text-lg font-bold text-gold-400">Rs {expectedCash.toLocaleString()}</div>
            </div>
          </div>

          {/* Closing Cash */}
          <div className="glass-light rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg bg-maroon-900/30 flex items-center justify-center">
                <Lock size={16} className="text-maroon-400" />
              </div>
              <div>
                <h3 className="text-sm font-dm font-semibold text-cream-100">Closing Cash</h3>
                <p className="text-[10px] text-navy-400 font-dm">End of day count</p>
              </div>
            </div>

            <div className="flex gap-2 mb-3">
              <input
                type="number"
                value={closingInput}
                onChange={e => setClosingInput(e.target.value)}
                placeholder="Count and enter closing cash"
                className="flex-1 px-3 py-2 rounded-xl bg-navy-800/60 border border-navy-600/30
                text-sm font-mono text-cream-200 placeholder:text-navy-500
                focus:outline-none focus:border-gold-500/40 transition-all"
              />
              <button
                onClick={handleSaveClosing}
                className="px-4 py-2 rounded-xl bg-maroon-600/20 border border-maroon-500/30 text-maroon-300 text-xs font-dm font-semibold hover:bg-maroon-600/30 transition-all"
              >
                Save
              </button>
            </div>

            {cashTally.closingCash > 0 && (
              <div className={`rounded-xl p-3 border ${
                difference >= 0
                  ? 'bg-green-900/20 border-green-500/30'
                  : 'bg-red-900/20 border-red-500/30'
              }`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    {difference >= 0 ? (
                      <TrendingUp size={14} className="text-green-400" />
                    ) : (
                      <TrendingDown size={14} className="text-red-400" />
                    )}
                    <span className="text-xs font-dm text-navy-200">
                      {difference >= 0 ? 'Over' : 'Short'}
                    </span>
                  </div>
                  <span className={`font-mono text-sm font-bold ${difference >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    Rs {Math.abs(difference).toLocaleString()}
                  </span>
                </div>
                {difference < 0 && (
                  <div className="flex items-center gap-1 mt-2 text-[10px] text-orange-400">
                    <AlertTriangle size={10} />
                    <span>Cash shortage detected</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
