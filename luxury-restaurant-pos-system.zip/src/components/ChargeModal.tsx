import { useState } from 'react';
import { X, Banknote, CreditCard, Check } from 'lucide-react';
import { OrderItem, PaymentMethod } from '../types';

interface ChargeModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: OrderItem[];
  subtotal: number;
  bagTotal: number;
  discountAmount: number;
  tax: number;
  grandTotal: number;
  paymentMethod: PaymentMethod;
  onConfirm: (cashReceived?: number) => void;
}

export default function ChargeModal({
  isOpen, onClose, items, subtotal, bagTotal, discountAmount, tax, grandTotal,
  paymentMethod, onConfirm
}: ChargeModalProps) {
  const [cashReceived, setCashReceived] = useState('');

  if (!isOpen) return null;

  const cashAmount = Number(cashReceived) || 0;
  const change = cashAmount - grandTotal;
  const canConfirm = paymentMethod === 'card' || cashAmount >= grandTotal;

  const handleConfirm = () => {
    if (paymentMethod === 'cash') {
      onConfirm(cashAmount);
    } else {
      onConfirm();
    }
    setCashReceived('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="glass rounded-3xl max-w-md w-full overflow-hidden animate-slide-up premium-shadow" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="p-5 border-b border-navy-700/50">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-playfair font-bold text-cream-100">Confirm Payment</h2>
            <button onClick={onClose} className="p-2 rounded-xl hover:bg-navy-700 text-navy-300 transition-all">
              <X size={18} />
            </button>
          </div>
        </div>

        <div className="p-5 space-y-4">
          {/* Items summary */}
          <div className="space-y-1.5 max-h-40 overflow-y-auto">
            {items.map(item => (
              <div key={item.sku + (item.size || '')} className="flex justify-between text-xs font-dm">
                <span className="text-navy-200">{item.name} x{item.qty}</span>
                <span className="font-mono text-cream-200">Rs {(item.price * item.qty).toLocaleString()}</span>
              </div>
            ))}
          </div>

          {/* Totals */}
          <div className="space-y-1.5 pt-3 border-t border-navy-700/50 text-xs font-dm">
            <div className="flex justify-between text-navy-300">
              <span>Subtotal</span><span className="font-mono">Rs {subtotal.toLocaleString()}</span>
            </div>
            {bagTotal > 0 && (
              <div className="flex justify-between text-navy-300">
                <span>Bags</span><span className="font-mono">Rs {bagTotal.toLocaleString()}</span>
              </div>
            )}
            {discountAmount > 0 && (
              <div className="flex justify-between text-green-400">
                <span>Discount</span><span className="font-mono">-Rs {Math.round(discountAmount).toLocaleString()}</span>
              </div>
            )}
            <div className="flex justify-between text-navy-300">
              <span>Tax (13%)</span><span className="font-mono">Rs {tax.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-lg font-bold text-gold-400 pt-2 border-t border-navy-700/50">
              <span className="font-playfair">Total</span>
              <span className="font-mono">Rs {grandTotal.toLocaleString()}</span>
            </div>
          </div>

          {/* Payment method badge */}
          <div className="flex items-center justify-center gap-2 glass-light rounded-xl p-3">
            {paymentMethod === 'cash' ? (
              <><Banknote size={18} className="text-green-400" /><span className="text-sm font-dm text-green-400 font-semibold">Cash Payment</span></>
            ) : (
              <><CreditCard size={18} className="text-blue-400" /><span className="text-sm font-dm text-blue-400 font-semibold">Card Payment</span></>
            )}
          </div>

          {/* Cash received */}
          {paymentMethod === 'cash' && (
            <div className="space-y-2">
              <label className="text-xs font-dm text-navy-300">Cash Received</label>
              <input
                type="number"
                value={cashReceived}
                onChange={e => setCashReceived(e.target.value)}
                placeholder="Enter amount"
                className="w-full px-4 py-3 rounded-xl bg-navy-800/60 border border-navy-600/30
                text-lg font-mono text-cream-200 placeholder:text-navy-500
                focus:outline-none focus:border-gold-500/40 transition-all text-center"
                autoFocus
              />

              {/* Quick amounts */}
              <div className="flex gap-1.5 flex-wrap">
                {[grandTotal, Math.ceil(grandTotal / 100) * 100, Math.ceil(grandTotal / 500) * 500, 1000, 2000, 5000].filter((v, i, a) => a.indexOf(v) === i).slice(0, 5).map(amt => (
                  <button
                    key={amt}
                    onClick={() => setCashReceived(String(amt))}
                    className="px-2.5 py-1 rounded-lg glass-light text-[11px] font-mono text-navy-200
                    hover:border-gold-500/30 hover:text-gold-300 transition-all"
                  >
                    Rs {amt.toLocaleString()}
                  </button>
                ))}
              </div>

              {cashAmount > 0 && (
                <div className={`rounded-xl p-3 text-center font-mono text-lg font-bold ${
                  change >= 0 ? 'bg-green-900/20 border border-green-500/30 text-green-400' : 'bg-red-900/20 border border-red-500/30 text-red-400'
                }`}>
                  {change >= 0 ? `Change: Rs ${change.toLocaleString()}` : `Short: Rs ${Math.abs(change).toLocaleString()}`}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="p-5 flex gap-2 border-t border-navy-700/50">
          <button
            onClick={onClose}
            className="flex-1 py-3 rounded-xl glass-light text-sm font-dm text-navy-300 hover:text-cream-200 transition-all"
          >
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            disabled={!canConfirm}
            className={`flex-1 py-3 rounded-xl text-sm font-playfair font-bold flex items-center justify-center gap-2 transition-all duration-300
            ${canConfirm
              ? 'bg-gradient-to-r from-green-600 to-green-700 text-white hover:from-green-500 hover:to-green-600 shadow-lg shadow-green-900/30'
              : 'bg-navy-700/50 text-navy-500 cursor-not-allowed'
            }`}
          >
            <Check size={16} />
            Confirm Payment
          </button>
        </div>
      </div>
    </div>
  );
}
