import { useState } from 'react';
import { X, Plus, MapPin, Phone, User, Truck, CheckCircle, Clock } from 'lucide-react';
import { DispatchInfo } from '../types';

interface DispatchModalProps {
  isOpen: boolean;
  onClose: () => void;
  dispatches: DispatchInfo[];
  onAddDispatch: (info: Omit<DispatchInfo, 'id' | 'timestamp' | 'status'>) => void;
  onMarkDelivered: (id: string) => void;
}

export default function DispatchModal({ isOpen, onClose, dispatches, onAddDispatch, onMarkDelivered }: DispatchModalProps) {
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [rider, setRider] = useState('');

  if (!isOpen) return null;

  const handleSubmit = () => {
    if (!name || !phone || !address || !amount) return;
    onAddDispatch({
      customerName: name,
      phone,
      address,
      riderName: rider || undefined,
      amount: Number(amount),
    });
    setName(''); setPhone(''); setAddress(''); setAmount(''); setRider('');
    setShowForm(false);
  };

  const pendingCount = dispatches.filter(d => d.status === 'pending').length;
  const deliveredCount = dispatches.filter(d => d.status === 'delivered').length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="glass rounded-3xl max-w-xl w-full max-h-[90vh] overflow-hidden animate-slide-up premium-shadow" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-5 border-b border-navy-700/50">
          <div>
            <h2 className="text-lg font-playfair font-bold text-cream-100">Dispatch Management</h2>
            <p className="text-xs text-navy-300 font-dm">
              <span className="text-orange-400">{pendingCount} pending</span>
              {' · '}
              <span className="text-green-400">{deliveredCount} delivered</span>
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowForm(!showForm)}
              className="p-2 rounded-xl bg-gold-600/20 text-gold-400 hover:bg-gold-600/30 transition-all"
            >
              <Plus size={16} />
            </button>
            <button onClick={onClose} className="p-2 rounded-xl hover:bg-navy-700 text-navy-300 transition-all">
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Form */}
        {showForm && (
          <div className="p-5 border-b border-navy-700/50 animate-fade-in">
            <h3 className="text-sm font-dm font-semibold text-cream-100 mb-3">New Dispatch</h3>
            <div className="grid grid-cols-2 gap-2 mb-2">
              <div className="relative">
                <User size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" />
                <input value={name} onChange={e => setName(e.target.value)} placeholder="Customer name"
                  className="w-full pl-8 pr-3 py-2 rounded-xl bg-navy-800/60 border border-navy-600/30 text-sm font-dm text-cream-200 placeholder:text-navy-500 focus:outline-none focus:border-gold-500/40 transition-all" />
              </div>
              <div className="relative">
                <Phone size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-navy-400" />
                <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="Phone"
                  className="w-full pl-8 pr-3 py-2 rounded-xl bg-navy-800/60 border border-navy-600/30 text-sm font-dm text-cream-200 placeholder:text-navy-500 focus:outline-none focus:border-gold-500/40 transition-all" />
              </div>
            </div>
            <div className="relative mb-2">
              <MapPin size={12} className="absolute left-3 top-3 text-navy-400" />
              <input value={address} onChange={e => setAddress(e.target.value)} placeholder="Delivery address"
                className="w-full pl-8 pr-3 py-2 rounded-xl bg-navy-800/60 border border-navy-600/30 text-sm font-dm text-cream-200 placeholder:text-navy-500 focus:outline-none focus:border-gold-500/40 transition-all" />
            </div>
            <div className="grid grid-cols-2 gap-2 mb-3">
              <input value={amount} onChange={e => setAmount(e.target.value)} placeholder="Amount (Rs)" type="number"
                className="w-full px-3 py-2 rounded-xl bg-navy-800/60 border border-navy-600/30 text-sm font-mono text-cream-200 placeholder:text-navy-500 focus:outline-none focus:border-gold-500/40 transition-all" />
              <input value={rider} onChange={e => setRider(e.target.value)} placeholder="Rider name (optional)"
                className="w-full px-3 py-2 rounded-xl bg-navy-800/60 border border-navy-600/30 text-sm font-dm text-cream-200 placeholder:text-navy-500 focus:outline-none focus:border-gold-500/40 transition-all" />
            </div>
            <button onClick={handleSubmit}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-gold-500 to-gold-600 text-navy-900 text-sm font-playfair font-bold hover:from-gold-400 hover:to-gold-500 transition-all">
              Add Dispatch
            </button>
          </div>
        )}

        {/* Dispatch list */}
        <div className="overflow-y-auto max-h-[55vh] p-5 space-y-2">
          {dispatches.length === 0 ? (
            <div className="text-center py-10">
              <Truck size={32} className="text-navy-600 mx-auto mb-2" />
              <p className="text-sm text-navy-400 font-dm">No dispatches yet</p>
            </div>
          ) : (
            dispatches.map(d => (
              <div key={d.id} className="glass-light rounded-xl p-3 animate-fade-in">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono text-xs font-bold text-gold-400">{d.id}</span>
                      <span className={`text-[9px] px-2 py-0.5 rounded-full border font-dm uppercase
                        ${d.status === 'pending' ? 'bg-orange-900/40 text-orange-300 border-orange-700/30' : 'bg-green-900/40 text-green-300 border-green-700/30'}`}>
                        {d.status === 'pending' ? <><Clock size={8} className="inline mr-0.5" />{d.status}</> : <><CheckCircle size={8} className="inline mr-0.5" />{d.status}</>}
                      </span>
                    </div>
                    <p className="text-sm font-dm font-semibold text-cream-200">{d.customerName}</p>
                    <p className="text-xs text-navy-300 font-dm flex items-center gap-1"><Phone size={10} />{d.phone}</p>
                    <p className="text-xs text-navy-400 font-dm flex items-center gap-1"><MapPin size={10} />{d.address}</p>
                    {d.riderName && <p className="text-xs text-blue-400 font-dm mt-1">🛵 {d.riderName}</p>}
                  </div>
                  <div className="text-right">
                    <div className="font-mono text-sm font-bold text-gold-400">Rs {d.amount.toLocaleString()}</div>
                    <div className="text-[10px] text-navy-400 font-mono mt-1">
                      {new Date(d.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>
                {d.status === 'pending' && (
                  <button
                    onClick={() => onMarkDelivered(d.id)}
                    className="w-full py-2 rounded-lg bg-green-900/20 border border-green-500/30 text-green-400 text-xs font-dm font-semibold
                    hover:bg-green-900/30 transition-all flex items-center justify-center gap-1"
                  >
                    <CheckCircle size={12} /> Mark Delivered
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
