import { useState } from 'react';
import { X, Plus, UserPlus, Trash2, UserCheck, UserX, Clock, Coffee } from 'lucide-react';
import { Employee, AttendanceRecord } from '../types';

interface AttendanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  employees: Employee[];
  attendance: AttendanceRecord[];
  onMarkAttendance: (empId: string, status: AttendanceRecord['status'], note?: string) => void;
  onAddEmployee: (emp: Omit<Employee, 'id'>) => void;
  onRemoveEmployee: (id: string) => void;
}

const today = () => new Date().toISOString().split('T')[0];

export default function AttendanceModal({
  isOpen, onClose, employees, attendance, onMarkAttendance, onAddEmployee, onRemoveEmployee
}: AttendanceModalProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState('');

  if (!isOpen) return null;

  const todayAttendance = attendance.filter(a => a.date === today());

  const getStatus = (empId: string): AttendanceRecord['status'] | null => {
    const record = todayAttendance.find(a => a.employeeId === empId);
    return record?.status || null;
  };

  const stats = {
    present: todayAttendance.filter(a => a.status === 'present').length,
    absent: todayAttendance.filter(a => a.status === 'absent').length,
    halfDay: todayAttendance.filter(a => a.status === 'half-day').length,
    leave: todayAttendance.filter(a => a.status === 'leave').length,
  };

  const statusOptions: { key: AttendanceRecord['status']; label: string; icon: React.ReactNode; color: string }[] = [
    { key: 'present', label: 'P', icon: <UserCheck size={10} />, color: 'bg-green-900/40 text-green-400 border-green-600/30 hover:bg-green-900/60' },
    { key: 'absent', label: 'A', icon: <UserX size={10} />, color: 'bg-red-900/40 text-red-400 border-red-600/30 hover:bg-red-900/60' },
    { key: 'half-day', label: 'H', icon: <Clock size={10} />, color: 'bg-yellow-900/40 text-yellow-400 border-yellow-600/30 hover:bg-yellow-900/60' },
    { key: 'leave', label: 'L', icon: <Coffee size={10} />, color: 'bg-purple-900/40 text-purple-400 border-purple-600/30 hover:bg-purple-900/60' },
  ];

  const handleAdd = () => {
    if (newName && newRole) {
      onAddEmployee({ name: newName, role: newRole });
      setNewName(''); setNewRole('');
      setShowAddForm(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="glass rounded-3xl max-w-lg w-full max-h-[90vh] overflow-hidden animate-slide-up premium-shadow" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-5 border-b border-navy-700/50">
          <div>
            <h2 className="text-lg font-playfair font-bold text-cream-100">Attendance</h2>
            <p className="text-xs text-navy-300 font-dm">{new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}</p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowAddForm(!showAddForm)} className="p-2 rounded-xl bg-gold-600/20 text-gold-400 hover:bg-gold-600/30 transition-all">
              <UserPlus size={16} />
            </button>
            <button onClick={onClose} className="p-2 rounded-xl hover:bg-navy-700 text-navy-300 transition-all">
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-2 p-5 pb-0">
          <div className="glass-light rounded-xl p-2 text-center">
            <div className="font-mono text-lg font-bold text-green-400">{stats.present}</div>
            <div className="text-[9px] text-navy-300 font-dm">Present</div>
          </div>
          <div className="glass-light rounded-xl p-2 text-center">
            <div className="font-mono text-lg font-bold text-red-400">{stats.absent}</div>
            <div className="text-[9px] text-navy-300 font-dm">Absent</div>
          </div>
          <div className="glass-light rounded-xl p-2 text-center">
            <div className="font-mono text-lg font-bold text-yellow-400">{stats.halfDay}</div>
            <div className="text-[9px] text-navy-300 font-dm">Half Day</div>
          </div>
          <div className="glass-light rounded-xl p-2 text-center">
            <div className="font-mono text-lg font-bold text-purple-400">{stats.leave}</div>
            <div className="text-[9px] text-navy-300 font-dm">Leave</div>
          </div>
        </div>

        {/* Add form */}
        {showAddForm && (
          <div className="p-5 pb-0 animate-fade-in">
            <div className="glass-light rounded-xl p-3 flex gap-2 items-end">
              <div className="flex-1">
                <label className="text-[10px] text-navy-400 font-dm">Name</label>
                <input value={newName} onChange={e => setNewName(e.target.value)} placeholder="Employee name"
                  className="w-full px-2 py-1.5 rounded-lg bg-navy-800/60 border border-navy-600/30 text-xs font-dm text-cream-200 placeholder:text-navy-500 focus:outline-none focus:border-gold-500/40 transition-all" />
              </div>
              <div className="flex-1">
                <label className="text-[10px] text-navy-400 font-dm">Role</label>
                <input value={newRole} onChange={e => setNewRole(e.target.value)} placeholder="Role"
                  className="w-full px-2 py-1.5 rounded-lg bg-navy-800/60 border border-navy-600/30 text-xs font-dm text-cream-200 placeholder:text-navy-500 focus:outline-none focus:border-gold-500/40 transition-all" />
              </div>
              <button onClick={handleAdd}
                className="px-3 py-1.5 rounded-lg bg-gold-600/20 text-gold-400 text-xs font-dm hover:bg-gold-600/30 transition-all flex items-center gap-1">
                <Plus size={12} /> Add
              </button>
            </div>
          </div>
        )}

        {/* Employee list */}
        <div className="overflow-y-auto max-h-[50vh] p-5 space-y-1.5">
          {employees.map(emp => {
            const status = getStatus(emp.id);
            return (
              <div key={emp.id} className="glass-light rounded-xl p-3 flex items-center justify-between animate-fade-in group">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-navy-600 to-navy-700 border border-navy-500/30 flex items-center justify-center text-xs font-bold text-gold-400 font-playfair">
                    {emp.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <p className="text-sm font-dm font-semibold text-cream-200">{emp.name}</p>
                    <p className="text-[10px] text-navy-400 font-dm">{emp.role} · {emp.id}</p>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  {statusOptions.map(opt => (
                    <button
                      key={opt.key}
                      onClick={() => onMarkAttendance(emp.id, opt.key)}
                      className={`w-7 h-7 rounded-lg border text-[10px] font-bold flex items-center justify-center transition-all duration-200
                      ${status === opt.key ? opt.color + ' ring-1 ring-white/20' : 'bg-navy-800/40 text-navy-500 border-navy-700/30 hover:border-navy-500/50'}`}
                      title={opt.key}
                    >
                      {opt.label}
                    </button>
                  ))}
                  <button
                    onClick={() => onRemoveEmployee(emp.id)}
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-navy-600 hover:text-red-400 hover:bg-red-900/20 transition-all opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 size={11} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
