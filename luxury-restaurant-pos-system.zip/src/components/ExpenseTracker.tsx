import { useState } from 'react';
import { X, Plus, Trash2, TrendingUp, TrendingDown, DollarSign, Utensils, Home, Users, Zap, MoreHorizontal } from 'lucide-react';
import { Expense } from '../types';

interface ExpenseTrackerProps {
  isOpen: boolean;
  onClose: () => void;
  expenses: Expense[];
  todayRevenue: number;
  onAddExpense: (exp: Omit<Expense, 'id'>) => void;
  onRemoveExpense: (id: string) => void;
}

const catOptions: { key: Expense['category']; label: string; icon: React.ReactNode; color: string }[] = [
  { key: 'ingredient', label: 'Ingredients', icon: <Utensils size={14} />, color: 'text-orange-400' },
  { key: 'rent', label: 'Rent', icon: <Home size={14} />, color: 'text-blue-400' },
  { key: 'salary', label: 'Salaries', icon: <Users size={14} />, color: 'text-green-400' },
  { key: 'utility', label: 'Utilities', icon: <Zap size={14} />, color: 'text-yellow-400' },
  { key: 'misc', label: 'Misc', icon: <MoreHorizontal size={14} />, color: 'text-purple-400' },
];

export default function ExpenseTracker({ isOpen, onClose, expenses, todayRevenue, onAddExpense, onRemoveExpense }: ExpenseTrackerProps) {
  const [showForm, setShowForm] = useState(false);
  const [cat, setCat] = useState<Expense['category']>('ingredient');
  const [desc, setDesc] = useState('');
  const [amount, setAmount] = useState('');

  if (!isOpen) return null;

  const totalExpenses = expenses.reduce((s, e) => s + e.amount, 0);
  const profit = todayRevenue - totalExpenses;
  const isProfit = profit >= 0;

  const expByCategory = catOptions.map(c => ({
    ...c,
    total: expenses.filter(e => e.category === c.key).reduce((s, e) => s + e.amount, 0),
    count: expenses.filter(e => e.category === c.key).length,
  }));

  const handleAdd = () => {
    if (desc && amount) {
      onAddExpense({ category: cat, description: desc, amount: Number(amount), date: new Date().toISOString().split('T')[0] });
      setDesc(''); setAmount('');
      setShowForm(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="glass rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-hidden animate-slide-up premium-shadow" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-5 border-b border-navy-700/50">
          <div>
            <h2 className="text-lg font-playfair font-bold text-cream-100">Expense Tracker</h2>
            <p className="text-xs text-navy-300 font-dm">Track costs & profitability</p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowForm(!showForm)} className="p-2 rounded-xl bg-gold-600/20 text-gold-400 hover:bg-gold-600/30 transition-all">
              <Plus size={16} />
            </button>
            <button onClick={onClose} className="p-2 rounded-xl hover:bg-navy-700 text-navy-300 transition-all">
              <X size={18} />
            </button>
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-3 gap-3 p-5 pb-0">
          <div className="glass-light rounded-xl p-3 text-center">
            <DollarSign size={16} className="text-green-400 mx-auto mb-1" />
            <div className="font-mono text-base font-bold text-green-400">Rs {todayRevenue.toLocaleString()}</div>
            <div className="text-[10px] text-navy-300 font-dm">Revenue</div>
          </div>
          <div className="glass-light rounded-xl p-3 text-center">
            <TrendingDown size={16} className="text-red-400 mx-auto mb-1" />
            <div className="font-mono text-base font-bold text-red-400">Rs {totalExpenses.toLocaleString()}</div>
            <div className="text-[10px] text-navy-300 font-dm">Expenses</div>
          </div>
          <div className={`glass-light rounded-xl p-3 text-center border ${isProfit ? 'border-green-700/30' : 'border-red-700/30'}`}>
            <TrendingUp size={16} className={`${isProfit ? 'text-green-400' : 'text-red-400'} mx-auto mb-1`} />
            <div className={`font-mono text-base font-bold ${isProfit ? 'text-green-400' : 'text-red-400'}`}>
              Rs {Math.abs(profit).toLocaleString()}
            </div>
            <div className="text-[10px] text-navy-300 font-dm">{isProfit ? 'Profit' : 'Loss'}</div>
          </div>
        </div>

        {/* Category breakdown */}
        <div className="flex gap-2 p-5 pb-0 overflow-x-auto">
          {expByCategory.map(c => (
            <div key={c.key} className="glass-light rounded-xl px-3 py-2 text-center min-w-[80px]">
              <div className={c.color}>{c.icon}</div>
              <div className="font-mono text-xs font-bold text-cream-200 mt-1">Rs {c.total.toLocaleString()}</div>
              <div className="text-[9px] text-navy-400 font-dm">{c.label}</div>
            </div>
          ))}
        </div>

        {/* Add form */}
        {showForm && (
          <div className="p-5 pb-0 animate-fade-in">
            <div className="glass-light rounded-xl p-3 space-y-2">
              <div className="flex gap-1 flex-wrap">
                {catOptions.map(c => (
                  <button
                    key={c.key}
                    onClick={() => setCat(c.key)}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-dm transition-all
                    ${cat === c.key ? 'bg-gold-600/20 text-gold-300 border border-gold-500/30' : 'glass text-navy-300 hover:text-cream-200'}`}
                  >
                    {c.icon} {c.label}
                  </button>
                ))}
              </div>
              <div className="flex gap-2">
                <input value={desc} onChange={e => setDesc(e.target.value)} placeholder="Description"
                  className="flex-1 px-3 py-2 rounded-xl bg-navy-800/60 border border-navy-600/30 text-sm font-dm text-cream-200 placeholder:text-navy-500 focus:outline-none focus:border-gold-500/40 transition-all" />
                <input value={amount} onChange={e => setAmount(e.target.value)} placeholder="Amount" type="number"
                  className="w-28 px-3 py-2 rounded-xl bg-navy-800/60 border border-navy-600/30 text-sm font-mono text-cream-200 placeholder:text-navy-500 focus:outline-none focus:border-gold-500/40 transition-all" />
                <button onClick={handleAdd}
                  className="px-4 py-2 rounded-xl bg-gold-600/20 text-gold-400 text-xs font-dm hover:bg-gold-600/30 transition-all">
                  Add
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Expense list */}
        <div className="overflow-y-auto max-h-[35vh] p-5 space-y-1">
          {expenses.length === 0 ? (
            <div className="text-center py-10 text-navy-400 font-dm text-sm">No expenses recorded</div>
          ) : (
            expenses.map(exp => {
              const catInfo = catOptions.find(c => c.key === exp.category);
              return (
                <div key={exp.id} className="glass-light rounded-xl p-3 flex items-center justify-between group animate-fade-in">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg glass flex items-center justify-center ${catInfo?.color || 'text-navy-400'}`}>
                      {catInfo?.icon}
                    </div>
                    <div>
                      <p className="text-sm font-dm text-cream-200">{exp.description}</p>
                      <p className="text-[10px] text-navy-400 font-dm">{catInfo?.label} · {exp.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm font-bold text-red-400">-Rs {exp.amount.toLocaleString()}</span>
                    <button
                      onClick={() => onRemoveExpense(exp.id)}
                      className="p-1.5 rounded-lg text-navy-600 hover:text-red-400 hover:bg-red-900/20 transition-all opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
