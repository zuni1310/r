import { useState, useEffect } from 'react';
import {
  Menu, DollarSign, Truck, UserCheck, Receipt, RotateCcw, ClipboardList,
  ExternalLink
} from 'lucide-react';

interface TopBarProps {
  totalOrders: number;
  totalRevenue: number;
  onToggleSidebar: () => void;
  onOpenCash: () => void;
  onOpenDispatch: () => void;
  onOpenAttendance: () => void;
  onOpenExpenses: () => void;
  onOpenSalesLog: () => void;
  onNewDay: () => void;
}

export default function TopBar({
  totalOrders, totalRevenue, onToggleSidebar,
  onOpenCash, onOpenDispatch, onOpenAttendance, onOpenExpenses,
  onOpenSalesLog, onNewDay
}: TopBarProps) {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass premium-shadow" style={{ borderBottom: '1px solid rgba(212,168,40,0.2)' }}>
      <div className="flex items-center justify-between px-3 py-2 lg:px-5">
        {/* Left */}
        <div className="flex items-center gap-2 lg:gap-3">
          <button
            onClick={onToggleSidebar}
            className="lg:hidden p-2 rounded-xl hover:bg-navy-700 transition-all duration-300"
          >
            <Menu size={20} className="text-gold-400" />
          </button>

          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center text-navy-900 font-bold text-sm font-playfair shadow-lg">
              Z
            </div>
            <div className="hidden sm:block">
              <h1 className="text-base lg:text-lg font-playfair font-bold bg-gradient-to-r from-gold-300 to-gold-500 bg-clip-text text-transparent leading-tight">
                ZUNIORA
              </h1>
              <p className="text-[10px] text-navy-300 font-dm -mt-0.5">Point of Sale</p>
            </div>
          </div>
        </div>

        {/* Center Pills */}
        <div className="hidden md:flex items-center gap-2">
          <div className="glass-light rounded-full px-3 py-1.5 flex items-center gap-1.5">
            <ClipboardList size={13} className="text-gold-400" />
            <span className="text-xs font-mono text-cream-200">{totalOrders}</span>
            <span className="text-[10px] text-navy-300">orders</span>
          </div>
          <div className="glass-light rounded-full px-3 py-1.5 flex items-center gap-1.5">
            <DollarSign size={13} className="text-green-400" />
            <span className="text-xs font-mono text-cream-200">Rs {totalRevenue.toLocaleString()}</span>
          </div>
          <div className="glass-light rounded-full px-3 py-1.5 flex items-center gap-1.5">
            <span className="text-xs font-mono text-gold-300">
              {time.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </span>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-1 lg:gap-1.5">
          <ActionBtn icon={<DollarSign size={15} />} label="Cash" onClick={onOpenCash} color="green" />
          <ActionBtn icon={<Truck size={15} />} label="Dispatch" onClick={onOpenDispatch} color="blue" />
          <ActionBtn icon={<UserCheck size={15} />} label="Attend" onClick={onOpenAttendance} color="purple" />
          <ActionBtn icon={<Receipt size={15} />} label="Expenses" onClick={onOpenExpenses} color="orange" />
          <ActionBtn icon={<RotateCcw size={15} />} label="New Day" onClick={onNewDay} color="red" />
          <ActionBtn icon={<ClipboardList size={15} />} label="Sales" onClick={onOpenSalesLog} color="gold" />
          <a
            href="https://zuniora.pk"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden xl:flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-dm text-gold-300 hover:text-gold-200 hover:bg-navy-700 transition-all duration-300"
          >
            <ExternalLink size={13} />
            <span>Web</span>
          </a>
        </div>
      </div>
    </header>
  );
}

function ActionBtn({ icon, label, onClick, color }: { icon: React.ReactNode; label: string; onClick: () => void; color: string }) {
  const colorMap: Record<string, string> = {
    green: 'hover:bg-green-900/40 hover:border-green-500/40 text-green-400',
    blue: 'hover:bg-blue-900/40 hover:border-blue-500/40 text-blue-400',
    purple: 'hover:bg-purple-900/40 hover:border-purple-500/40 text-purple-400',
    orange: 'hover:bg-orange-900/40 hover:border-orange-500/40 text-orange-400',
    red: 'hover:bg-red-900/40 hover:border-red-500/40 text-red-400',
    gold: 'hover:bg-gold-900/40 hover:border-gold-500/40 text-gold-400',
  };

  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-1 px-2 lg:px-2.5 py-1.5 rounded-lg text-xs font-dm border border-transparent transition-all duration-300 ${colorMap[color] || colorMap.gold}`}
    >
      {icon}
      <span className="hidden lg:inline">{label}</span>
    </button>
  );
}
