import { useRef } from 'react';
import { X, Printer } from 'lucide-react';
import { Order } from '../types';

interface ReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
}

export default function ReceiptModal({ isOpen, onClose, order }: ReceiptModalProps) {
  const receiptRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !order) return null;

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (printWindow && receiptRef.current) {
      printWindow.document.write(`
        <html><head><title>Receipt</title>
        <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: 'JetBrains Mono', monospace; background: white; }
          @media print { @page { margin: 0; size: 80mm auto; } }
        </style>
        </head><body>${receiptRef.current.innerHTML}</body></html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const dateObj = new Date(order.timestamp);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="glass rounded-3xl max-w-sm w-full overflow-hidden animate-slide-up premium-shadow" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-navy-700/50">
          <h2 className="text-base font-playfair font-bold text-cream-100">Receipt</h2>
          <div className="flex items-center gap-2">
            <button onClick={handlePrint} className="p-2 rounded-xl hover:bg-navy-700 text-gold-400 transition-all">
              <Printer size={16} />
            </button>
            <button onClick={onClose} className="p-2 rounded-xl hover:bg-navy-700 text-navy-300 transition-all">
              <X size={16} />
            </button>
          </div>
        </div>

        <div className="max-h-[70vh] overflow-y-auto p-4">
          <div ref={receiptRef}>
            <div style={{
              fontFamily: "'JetBrains Mono', monospace",
              background: 'white',
              color: 'black',
              padding: '20px',
              maxWidth: '300px',
              margin: '0 auto',
              fontSize: '11px',
              lineHeight: '1.6',
            }}>
              {/* Header */}
              <div style={{ textAlign: 'center', marginBottom: '12px' }}>
                <div style={{ fontSize: '22px', fontWeight: 'bold', letterSpacing: '3px' }}>ZUNIORA</div>
                <div style={{ fontSize: '9px', letterSpacing: '2px', marginTop: '2px' }}>PREMIUM FAST FOOD</div>
                <div style={{ borderBottom: '2px dashed #000', margin: '8px 0' }} />
                <div style={{ fontSize: '9px' }}>Shop No. 13, Mall Road</div>
                <div style={{ fontSize: '9px' }}>Murree, Pakistan</div>
                <div style={{ fontSize: '9px' }}>Tel: 03418243656</div>
                <div style={{ fontSize: '9px' }}>www.zuniora.pk</div>
              </div>

              <div style={{ borderBottom: '1px dashed #999', margin: '8px 0' }} />

              {/* Order info */}
              <div style={{ fontSize: '10px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Order:</span><span style={{ fontWeight: 'bold' }}>{order.id}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Date:</span><span>{dateObj.toLocaleDateString()}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Time:</span><span>{dateObj.toLocaleTimeString()}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Type:</span>
                  <span style={{ fontWeight: 'bold', textTransform: 'uppercase' }}>{order.orderType}</span>
                </div>
                {order.table && (
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>Table:</span><span>{order.table}</span>
                  </div>
                )}
              </div>

              <div style={{ borderBottom: '1px dashed #999', margin: '8px 0' }} />

              {/* Items */}
              <table style={{ width: '100%', fontSize: '10px', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid #999' }}>
                    <th style={{ textAlign: 'left', paddingBottom: '4px' }}>Item</th>
                    <th style={{ textAlign: 'center', paddingBottom: '4px' }}>Qty</th>
                    <th style={{ textAlign: 'right', paddingBottom: '4px' }}>Amt</th>
                  </tr>
                </thead>
                <tbody>
                  {order.items.map((item, idx) => (
                    <tr key={idx}>
                      <td style={{ paddingTop: '3px', maxWidth: '140px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.name}</td>
                      <td style={{ textAlign: 'center', paddingTop: '3px' }}>{item.qty}</td>
                      <td style={{ textAlign: 'right', paddingTop: '3px' }}>{(item.price * item.qty).toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div style={{ borderBottom: '1px dashed #999', margin: '8px 0' }} />

              {/* Totals */}
              <div style={{ fontSize: '10px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Subtotal:</span><span>Rs {order.subtotal.toLocaleString()}</span>
                </div>
                {order.bagTotal > 0 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>Bags:</span><span>Rs {order.bagTotal.toLocaleString()}</span>
                  </div>
                )}
                {order.discount > 0 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>Discount:</span><span>-Rs {Math.round(order.discount).toLocaleString()}</span>
                  </div>
                )}
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Tax (13%):</span><span>Rs {order.tax.toLocaleString()}</span>
                </div>

                <div style={{ borderBottom: '2px solid #000', margin: '6px 0' }} />

                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px', fontWeight: 'bold' }}>
                  <span>TOTAL:</span><span>Rs {order.total.toLocaleString()}</span>
                </div>
              </div>

              <div style={{ borderBottom: '1px dashed #999', margin: '8px 0' }} />

              {/* Payment */}
              <div style={{ fontSize: '10px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Payment:</span>
                  <span style={{ fontWeight: 'bold', textTransform: 'uppercase' }}>{order.paymentMethod}</span>
                </div>
                {order.cashReceived !== undefined && (
                  <>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span>Received:</span><span>Rs {order.cashReceived.toLocaleString()}</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold' }}>
                      <span>Change:</span><span>Rs {(order.change ?? 0).toLocaleString()}</span>
                    </div>
                  </>
                )}
              </div>

              <div style={{ borderBottom: '2px dashed #000', margin: '10px 0' }} />

              {/* Footer */}
              <div style={{ textAlign: 'center', fontSize: '9px' }}>
                <div style={{ fontWeight: 'bold', fontSize: '11px', marginBottom: '4px' }}>Thank You!</div>
                <div>Visit us again at ZUNIORA</div>
                <div>Your premium dining experience</div>
                <div style={{ marginTop: '6px', fontSize: '8px', color: '#666' }}>
                  Powered by ZUNIORA POS System
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
