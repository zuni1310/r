import { useState } from 'react';
import { X, ChevronDown, ChevronUp, Receipt, DollarSign, ShoppingCart } from 'lucide-react';
import { Order } from '../types';

interface SalesLogProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
  onViewReceipt: (order: Order) => void;
}

export default function SalesLog({ isOpen, onClose, orders, onViewReceipt }: SalesLogProps) {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | 'dine-in' | 'package' | 'dispatch'>('all');

  if (!isOpen) return null;

  const filtered = filter === 'all' ? orders : orders.filter(o => o.orderType === filter);
  const totalRevenue = filtered.reduce((s, o) => s + o.total, 0);
  const cashOrders = filtered.filter(o => o.paymentMethod === 'cash');
  const cardOrders = filtered.filter(o => o.paymentMethod === 'card');

  const typeBadge = (type: string) => {
    const c: Record<string, string> = {
      'dine-in': 'bg-blue-900/40 text-blue-300 border-blue-700/30',
      'package': 'bg-purple-900/40 text-purple-300 border-purple-700/30',
      'dispatch': 'bg-orange-900/40 text-orange-300 border-orange-700/30',
    };
    return c[type] || c['dine-in'];
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="glass rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-hidden animate-slide-up premium-shadow" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-navy-700/50">
          <div>
            <h2 className="text-lg font-playfair font-bold text-cream-100">Sales Log</h2>
            <p className="text-xs text-navy-300 font-dm">Order history & analytics</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-navy-700 text-navy-300 transition-all">
            <X size={18} />
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 p-5 pb-0">
          <div className="glass-light rounded-xl p-3 text-center">
            <ShoppingCart size={16} className="text-gold-400 mx-auto mb-1" />
            <div className="font-mono text-lg font-bold text-cream-100">{filtered.length}</div>
            <div className="text-[10px] text-navy-300 font-dm">Total Orders</div>
          </div>
          <div className="glass-light rounded-xl p-3 text-center">
            <DollarSign size={16} className="text-green-400 mx-auto mb-1" />
            <div className="font-mono text-lg font-bold text-green-400">Rs {totalRevenue.toLocaleString()}</div>
            <div className="text-[10px] text-navy-300 font-dm">Revenue</div>
          </div>
          <div className="glass-light rounded-xl p-3 text-center">
            <Receipt size={16} className="text-blue-400 mx-auto mb-1" />
            <div className="font-mono text-sm font-bold text-cream-100">
              {cashOrders.length} / {cardOrders.length}
            </div>
            <div className="text-[10px] text-navy-300 font-dm">Cash / Card</div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-1.5 p-5 pb-3">
          {(['all', 'dine-in', 'package', 'dispatch'] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-dm capitalize transition-all
              ${filter === f ? 'bg-gold-600/20 text-gold-300 border border-gold-500/30' : 'glass-light text-navy-300 hover:text-cream-200'}`}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Orders list */}
        <div className="overflow-y-auto max-h-[45vh] px-5 pb-5 space-y-1.5">
          {filtered.length === 0 ? (
            <div className="text-center py-10 text-navy-400 font-dm text-sm">No orders found</div>
          ) : (
            filtered.map(order => (
              <div key={order.id} className="glass-light rounded-xl overflow-hidden">
                <button
                  onClick={() => setExpandedId(expandedId === order.id ? null : order.id)}
                  className="w-full flex items-center justify-between p-3 hover:bg-navy-700/30 transition-all"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs font-bold text-gold-400">{order.id}</span>
                    <span className={`text-[9px] px-2 py-0.5 rounded-full border font-dm uppercase ${typeBadge(order.orderType)}`}>
                      {order.orderType}
                    </span>
                    <span className={`text-[9px] px-2 py-0.5 rounded-full border font-dm uppercase
                      ${order.paymentMethod === 'cash' ? 'bg-green-900/40 text-green-300 border-green-700/30' : 'bg-blue-900/40 text-blue-300 border-blue-700/30'}`}>
                      {order.paymentMethod}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-sm font-bold text-cream-200">Rs {order.total.toLocaleString()}</span>
                    <span className="text-[10px] text-navy-400 font-mono hidden sm:inline">
                      {new Date(order.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    {expandedId === order.id ? <ChevronUp size={14} className="text-navy-400" /> : <ChevronDown size={14} className="text-navy-400" />}
                  </div>
                </button>

                {expandedId === order.id && (
                  <div className="px-3 pb-3 border-t border-navy-700/30 animate-fade-in">
                    <div className="space-y-1 pt-2">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="flex justify-between text-xs font-dm text-navy-200">
                          <span>{item.name} x{item.qty}</span>
                          <span className="font-mono">Rs {(item.price * item.qty).toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-end mt-2">
                      <button
                        onClick={() => onViewReceipt(order)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-gold-600/20 text-gold-300 text-xs font-dm hover:bg-gold-600/30 transition-all"
                      >
                        <Receipt size={12} /> View Receipt
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
