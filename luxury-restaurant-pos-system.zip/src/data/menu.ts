import { MenuItem } from '../types';

export const menuItems: MenuItem[] = [
  // Burgers
  { sku: 'B01', cat: 'burgers', name: 'Classic Zuni Beef Burger', price: 490, heat: 'Mild', cal: 620 },
  { sku: 'B02', cat: 'burgers', name: 'Double Smash Burger', price: 690, heat: 'Medium', cal: 850 },
  { sku: 'B03', cat: 'burgers', name: 'Spicy Inferno Burger', price: 590, heat: 'Hot', cal: 720 },
  { sku: 'B04', cat: 'burgers', name: 'Mushroom Swiss Burger', price: 650, heat: 'Mild', cal: 680 },
  { sku: 'B05', cat: 'burgers', name: 'BBQ Bacon Burger', price: 750, heat: 'Medium', cal: 890 },
  { sku: 'B06', cat: 'burgers', name: 'Veggie Deluxe Burger', price: 420, heat: 'None', cal: 450 },

  // Chicken
  { sku: 'C01', cat: 'chicken', name: 'Crispy Fried Chicken (2pc)', price: 450, heat: 'Mild', cal: 560 },
  { sku: 'C02', cat: 'chicken', name: 'Spicy Wings (6pc)', price: 520, heat: 'Hot', cal: 480 },
  { sku: 'C03', cat: 'chicken', name: 'Grilled Chicken Breast', price: 580, heat: 'Mild', cal: 350 },
  { sku: 'C04', cat: 'chicken', name: 'Chicken Tenders (5pc)', price: 490, heat: 'None', cal: 520 },
  { sku: 'C05', cat: 'chicken', name: 'Nashville Hot Chicken', price: 620, heat: 'Hot', cal: 640 },

  // Wraps
  { sku: 'W01', cat: 'wraps', name: 'Classic Chicken Wrap', price: 390, heat: 'Mild', cal: 420 },
  { sku: 'W02', cat: 'wraps', name: 'Spicy Shawarma Wrap', price: 450, heat: 'Hot', cal: 480 },
  { sku: 'W03', cat: 'wraps', name: 'Caesar Wrap', price: 420, heat: 'None', cal: 380 },
  { sku: 'W04', cat: 'wraps', name: 'BBQ Ranch Wrap', price: 470, heat: 'Medium', cal: 510 },

  // Potatoes
  { sku: 'P01', cat: 'potatoes', name: 'Classic French Fries', price: 220, heat: 'None', cal: 340, sizes: [{ name: 'Regular', price: 220 }, { name: 'Large', price: 320 }] },
  { sku: 'P02', cat: 'potatoes', name: 'Loaded Cheese Fries', price: 350, heat: 'Mild', cal: 520 },
  { sku: 'P03', cat: 'potatoes', name: 'Curly Fries', price: 280, heat: 'None', cal: 360 },
  { sku: 'P04', cat: 'potatoes', name: 'Wedge Potatoes', price: 300, heat: 'Mild', cal: 380 },
  { sku: 'P05', cat: 'potatoes', name: 'Peri Peri Fries', price: 290, heat: 'Hot', cal: 350 },

  // Breakfast
  { sku: 'BK01', cat: 'breakfast', name: 'Classic Egg Muffin', price: 290, heat: 'None', cal: 350 },
  { sku: 'BK02', cat: 'breakfast', name: 'Pancake Stack', price: 380, heat: 'None', cal: 480 },
  { sku: 'BK03', cat: 'breakfast', name: 'Breakfast Burrito', price: 420, heat: 'Mild', cal: 520 },
  { sku: 'BK04', cat: 'breakfast', name: 'French Toast Platter', price: 350, heat: 'None', cal: 440 },

  // Desserts
  { sku: 'D01', cat: 'desserts', name: 'Chocolate Lava Cake', price: 350, heat: 'None', cal: 480 },
  { sku: 'D02', cat: 'desserts', name: 'Churros (6pc)', price: 280, heat: 'None', cal: 320 },
  { sku: 'D03', cat: 'desserts', name: 'Sundae Supreme', price: 320, heat: 'None', cal: 420 },
  { sku: 'D04', cat: 'desserts', name: 'Apple Pie Slice', price: 250, heat: 'None', cal: 340 },

  // Beverages
  { sku: 'BV01', cat: 'beverages', name: 'Fresh Lemonade', price: 180, heat: 'None', cal: 120, sizes: [{ name: 'Regular', price: 180 }, { name: 'Large', price: 250 }] },
  { sku: 'BV02', cat: 'beverages', name: 'Iced Coffee', price: 280, heat: 'None', cal: 180, sizes: [{ name: 'Regular', price: 280 }, { name: 'Large', price: 380 }] },
  { sku: 'BV03', cat: 'beverages', name: 'Mango Smoothie', price: 320, heat: 'None', cal: 240 },
  { sku: 'BV04', cat: 'beverages', name: 'Mint Mojito', price: 250, heat: 'None', cal: 140 },
  { sku: 'BV05', cat: 'beverages', name: 'Hot Chocolate', price: 290, heat: 'None', cal: 280 },

  // Combos
  { sku: 'CM01', cat: 'combos', name: 'Burger + Fries + Drink', price: 790, heat: 'Mild', cal: 1100 },
  { sku: 'CM02', cat: 'combos', name: 'Chicken Meal Deal', price: 850, heat: 'Mild', cal: 1200 },
  { sku: 'CM03', cat: 'combos', name: 'Family Feast (4 persons)', price: 2490, heat: 'Mild', cal: 3200 },
  { sku: 'CM04', cat: 'combos', name: 'Couple Combo', price: 1490, heat: 'Mild', cal: 2000 },

  // Kids Menu
  { sku: 'K01', cat: 'kids', name: 'Mini Burger Meal', price: 390, heat: 'None', cal: 420 },
  { sku: 'K02', cat: 'kids', name: 'Nuggets & Fries', price: 350, heat: 'None', cal: 380 },
  { sku: 'K03', cat: 'kids', name: 'Junior Wrap Meal', price: 370, heat: 'None', cal: 400 },
];

export const categories = [
  { id: 'burgers', name: 'Burgers', icon: '🍔' },
  { id: 'chicken', name: 'Chicken', icon: '🍗' },
  { id: 'wraps', name: 'Wraps', icon: '🌯' },
  { id: 'potatoes', name: 'Potatoes', icon: '🍟' },
  { id: 'breakfast', name: 'Breakfast', icon: '🍳' },
  { id: 'desserts', name: 'Desserts', icon: '🍰' },
  { id: 'beverages', name: 'Beverages', icon: '🥤' },
  { id: 'combos', name: 'Combos', icon: '🎁' },
  { id: 'kids', name: 'Kids Menu', icon: '👶' },
];
