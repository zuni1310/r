import { useState, useCallback, useEffect } from 'react';
import { OrderItem, Order, OrderType, PaymentMethod, TableState, DispatchInfo, Employee, AttendanceRecord, Expense, CashTally } from '../types';

function loadFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : defaultValue;
  } catch {
    return defaultValue;
  }
}

function saveToStorage(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch { /* ignore */ }
}

const today = () => new Date().toISOString().split('T')[0];

export function useStore() {
  // Order state
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [orderType, setOrderType] = useState<OrderType>('dine-in');
  const [selectedTable, setSelectedTable] = useState<number | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [discountValue, setDiscountValue] = useState(0);
  const [discountType, setDiscountType] = useState<'percent' | 'flat'>('percent');
  const [bagQty, setBagQty] = useState(0);
  const bagCost = 20;

  // Tables
  const [tables, setTables] = useState<TableState[]>(
    loadFromStorage('zuniora_tables', Array.from({ length: 8 }, (_, i) => ({ id: i + 1, status: 'empty' as const })))
  );

  // Orders
  const [orders, setOrders] = useState<Order[]>(loadFromStorage('zuniora_orders', []));

  // Dispatch
  const [dispatches, setDispatches] = useState<DispatchInfo[]>(loadFromStorage('zuniora_dispatches', []));

  // Employees & Attendance
  const [employees, setEmployees] = useState<Employee[]>(loadFromStorage('zuniora_employees', [
    { id: 'E001', name: 'Ali Hassan', role: 'Cashier' },
    { id: 'E002', name: 'Sara Khan', role: 'Chef' },
    { id: 'E003', name: 'Ahmed Raza', role: 'Waiter' },
    { id: 'E004', name: 'Fatima Noor', role: 'Manager' },
    { id: 'E005', name: 'Usman Tariq', role: 'Rider' },
  ]));
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(loadFromStorage('zuniora_attendance', []));

  // Expenses
  const [expenses, setExpenses] = useState<Expense[]>(loadFromStorage('zuniora_expenses', []));

  // Cash tally
  const [cashTally, setCashTally] = useState<CashTally>(loadFromStorage('zuniora_cash_tally', {
    date: today(),
    openingCash: 0,
    salesCash: 0,
    closingCash: 0,
    expectedCash: 0,
    difference: 0,
  }));

  // Save to storage
  useEffect(() => { saveToStorage('zuniora_tables', tables); }, [tables]);
  useEffect(() => { saveToStorage('zuniora_orders', orders); }, [orders]);
  useEffect(() => { saveToStorage('zuniora_dispatches', dispatches); }, [dispatches]);
  useEffect(() => { saveToStorage('zuniora_employees', employees); }, [employees]);
  useEffect(() => { saveToStorage('zuniora_attendance', attendance); }, [attendance]);
  useEffect(() => { saveToStorage('zuniora_expenses', expenses); }, [expenses]);
  useEffect(() => { saveToStorage('zuniora_cash_tally', cashTally); }, [cashTally]);

  const addToOrder = useCallback((item: OrderItem) => {
    setOrderItems(prev => {
      const key = item.sku + (item.size || '');
      const existing = prev.find(i => i.sku + (i.size || '') === key);
      if (existing) {
        return prev.map(i => (i.sku + (i.size || '') === key ? { ...i, qty: i.qty + 1 } : i));
      }
      return [...prev, { ...item, qty: 1 }];
    });
  }, []);

  const updateQty = useCallback((sku: string, size: string | undefined, delta: number) => {
    setOrderItems(prev => {
      const key = sku + (size || '');
      return prev
        .map(i => (i.sku + (i.size || '') === key ? { ...i, qty: Math.max(0, i.qty + delta) } : i))
        .filter(i => i.qty > 0);
    });
  }, []);

  const removeItem = useCallback((sku: string, size: string | undefined) => {
    setOrderItems(prev => prev.filter(i => i.sku + (i.size || '') !== sku + (size || '')));
  }, []);

  const clearOrder = useCallback(() => {
    setOrderItems([]);
    setDiscountValue(0);
    setBagQty(0);
    setSelectedTable(null);
  }, []);

  const subtotal = orderItems.reduce((s, i) => s + i.price * i.qty, 0);
  const bagTotal = bagQty * bagCost;
  const discountAmount = discountType === 'percent' ? (subtotal * discountValue) / 100 : discountValue;
  const afterDiscount = Math.max(0, subtotal - discountAmount);
  const tax = Math.round(afterDiscount * 0.13);
  const grandTotal = afterDiscount + tax + bagTotal;

  const todayOrders = orders.filter(o => o.date === today());
  const todayRevenue = todayOrders.reduce((s, o) => s + o.total, 0);

  const confirmOrder = useCallback((cashReceived?: number) => {
    const orderId = 'ZN-' + Date.now().toString(36).toUpperCase();
    const order: Order = {
      id: orderId,
      items: [...orderItems],
      orderType,
      table: selectedTable ?? undefined,
      subtotal,
      bagTotal,
      discount: discountAmount,
      discountType,
      discountValue,
      tax,
      total: grandTotal,
      paymentMethod,
      cashReceived: paymentMethod === 'cash' ? cashReceived : undefined,
      change: paymentMethod === 'cash' && cashReceived ? cashReceived - grandTotal : undefined,
      timestamp: new Date().toISOString(),
      date: today(),
    };

    setOrders(prev => [order, ...prev]);

    if (paymentMethod === 'cash') {
      setCashTally(prev => ({
        ...prev,
        salesCash: prev.salesCash + grandTotal,
        expectedCash: prev.openingCash + prev.salesCash + grandTotal,
      }));
    }

    if (selectedTable) {
      setTables(prev => prev.map(t => t.id === selectedTable ? { ...t, status: 'empty' as const, orderId: undefined } : t));
    }

    clearOrder();
    return order;
  }, [orderItems, orderType, selectedTable, subtotal, bagTotal, discountAmount, discountType, discountValue, tax, grandTotal, paymentMethod, clearOrder]);

  const selectTable = useCallback((tableId: number) => {
    setSelectedTable(tableId);
    setTables(prev => prev.map(t => t.id === tableId ? { ...t, status: 'active' as const } : t));
  }, []);

  const addDispatch = useCallback((info: Omit<DispatchInfo, 'id' | 'timestamp' | 'status'>) => {
    const dispatch: DispatchInfo = {
      ...info,
      id: 'DSP-' + Date.now().toString(36).toUpperCase(),
      status: 'pending',
      timestamp: new Date().toISOString(),
    };
    setDispatches(prev => [dispatch, ...prev]);
    return dispatch;
  }, []);

  const markDelivered = useCallback((id: string) => {
    setDispatches(prev => prev.map(d => d.id === id ? { ...d, status: 'delivered' as const } : d));
  }, []);

  const addEmployee = useCallback((emp: Omit<Employee, 'id'>) => {
    setEmployees(prev => [...prev, { ...emp, id: 'E' + String(prev.length + 1).padStart(3, '0') }]);
  }, []);

  const removeEmployee = useCallback((id: string) => {
    setEmployees(prev => prev.filter(e => e.id !== id));
  }, []);

  const markAttendance = useCallback((employeeId: string, status: AttendanceRecord['status'], note?: string) => {
    setAttendance(prev => {
      const key = employeeId + today();
      const existing = prev.find(a => a.employeeId + a.date === key);
      if (existing) {
        return prev.map(a => a.employeeId + a.date === key ? { ...a, status, note } : a);
      }
      return [...prev, { employeeId, date: today(), status, note }];
    });
  }, []);

  const addExpense = useCallback((exp: Omit<Expense, 'id'>) => {
    setExpenses(prev => [...prev, { ...exp, id: 'EXP-' + Date.now().toString(36).toUpperCase() }]);
  }, []);

  const removeExpense = useCallback((id: string) => {
    setExpenses(prev => prev.filter(e => e.id !== id));
  }, []);

  const setOpeningCash = useCallback((amount: number) => {
    setCashTally(prev => ({
      ...prev,
      openingCash: amount,
      lockedAt: new Date().toISOString(),
      expectedCash: amount + prev.salesCash,
    }));
  }, []);

  const setClosingCash = useCallback((amount: number) => {
    setCashTally(prev => ({
      ...prev,
      closingCash: amount,
      difference: amount - prev.expectedCash,
    }));
  }, []);

  const resetDay = useCallback(() => {
    setOrders([]);
    setDispatches([]);
    setTables(Array.from({ length: 8 }, (_, i) => ({ id: i + 1, status: 'empty' as const })));
    setCashTally({ date: today(), openingCash: 0, salesCash: 0, closingCash: 0, expectedCash: 0, difference: 0 });
    clearOrder();
  }, [clearOrder]);

  return {
    // Order
    orderItems, orderType, setOrderType,
    selectedTable, selectTable, setSelectedTable,
    paymentMethod, setPaymentMethod,
    discountValue, setDiscountValue,
    discountType, setDiscountType,
    bagQty, setBagQty, bagCost,
    addToOrder, updateQty, removeItem, clearOrder,
    subtotal, bagTotal, discountAmount, tax, grandTotal,
    confirmOrder,
    // Tables
    tables, setTables,
    // Orders history
    orders, todayOrders, todayRevenue,
    // Dispatch
    dispatches, addDispatch, markDelivered,
    // Employees
    employees, addEmployee, removeEmployee,
    attendance, markAttendance,
    // Expenses
    expenses, addExpense, removeExpense,
    // Cash
    cashTally, setOpeningCash, setClosingCash,
    // Reset
    resetDay,
  };
}
