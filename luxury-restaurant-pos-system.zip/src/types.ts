export interface MenuItem {
  sku: string;
  cat: string;
  name: string;
  price: number;
  heat: 'Mild' | 'Medium' | 'Hot' | 'None';
  cal: number;
  sizes?: { name: string; price: number }[];
}

export interface OrderItem {
  sku: string;
  name: string;
  price: number;
  qty: number;
  size?: string;
}

export type OrderType = 'dine-in' | 'package' | 'dispatch';
export type PaymentMethod = 'cash' | 'card';

export interface Order {
  id: string;
  items: OrderItem[];
  orderType: OrderType;
  table?: number;
  subtotal: number;
  bagTotal: number;
  discount: number;
  discountType: 'percent' | 'flat';
  discountValue: number;
  tax: number;
  total: number;
  paymentMethod: PaymentMethod;
  cashReceived?: number;
  change?: number;
  timestamp: string;
  date: string;
  dispatchInfo?: DispatchInfo;
}

export interface TableState {
  id: number;
  status: 'empty' | 'occupied' | 'active';
  orderId?: string;
}

export interface DispatchInfo {
  id: string;
  customerName: string;
  phone: string;
  address: string;
  riderName?: string;
  status: 'pending' | 'delivered';
  amount: number;
  timestamp: string;
}

export interface Employee {
  id: string;
  name: string;
  role: string;
}

export interface AttendanceRecord {
  employeeId: string;
  date: string;
  status: 'present' | 'absent' | 'half-day' | 'leave';
  note?: string;
}

export interface Expense {
  id: string;
  category: 'ingredient' | 'rent' | 'salary' | 'utility' | 'misc';
  description: string;
  amount: number;
  date: string;
}

export interface CashTally {
  date: string;
  openingCash: number;
  lockedAt?: string;
  salesCash: number;
  closingCash: number;
  expectedCash: number;
  difference: number;
}
