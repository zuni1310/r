import { useState, useCallback } from 'react';
import { ShoppingCart } from 'lucide-react';
import { useStore } from './store/useStore';
import { Order } from './types';
import TopBar from './components/TopBar';
import Sidebar from './components/Sidebar';
import MenuGrid from './components/MenuGrid';
import OrderPanel from './components/OrderPanel';
import ChargeModal from './components/ChargeModal';
import ReceiptModal from './components/ReceiptModal';
import ManagerAuth from './components/ManagerAuth';
import SalesLog from './components/SalesLog';
import CashManagement from './components/CashManagement';
import DispatchModal from './components/DispatchModal';
import AttendanceModal from './components/AttendanceModal';
import ExpenseTracker from './components/ExpenseTracker';

export default function App() {
  const store = useStore();

  // UI State
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [orderPanelOpen, setOrderPanelOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('burgers');

  // Modals
  const [chargeModalOpen, setChargeModalOpen] = useState(false);
  const [receiptOrder, setReceiptOrder] = useState<Order | null>(null);
  const [salesLogOpen, setSalesLogOpen] = useState(false);
  const [cashModalOpen, setCashModalOpen] = useState(false);
  const [dispatchModalOpen, setDispatchModalOpen] = useState(false);
  const [attendanceModalOpen, setAttendanceModalOpen] = useState(false);
  const [expenseModalOpen, setExpenseModalOpen] = useState(false);

  // Manager auth
  const [managerAuthOpen, setManagerAuthOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);
  const [authTitle, setAuthTitle] = useState('');

  const requireAuth = useCallback((title: string, action: () => void) => {
    setAuthTitle(title);
    setPendingAction(() => action);
    setManagerAuthOpen(true);
  }, []);

  const handleAuthSuccess = useCallback(() => {
    setManagerAuthOpen(false);
    if (pendingAction) {
      pendingAction();
      setPendingAction(null);
    }
  }, [pendingAction]);

  const handleCharge = useCallback(() => {
    if (store.orderItems.length === 0) return;
    if (store.orderType === 'dine-in' && !store.selectedTable) {
      alert('Please select a table for dine-in orders');
      return;
    }
    setChargeModalOpen(true);
  }, [store.orderItems.length, store.orderType, store.selectedTable]);

  const handleConfirmPayment = useCallback((cashReceived?: number) => {
    const order = store.confirmOrder(cashReceived);
    setChargeModalOpen(false);
    setReceiptOrder(order);
  }, [store]);

  const handleNewDay = useCallback(() => {
    requireAuth('New Day Reset', () => {
      store.resetDay();
    });
  }, [requireAuth, store]);

  const handleUnlockCash = useCallback(() => {
    requireAuth('Unlock Cash Register', () => {
      // Reset the lock
      store.setOpeningCash(0);
    });
  }, [requireAuth, store]);

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden bg-navy-950">
      {/* Top Bar */}
      <TopBar
        totalOrders={store.todayOrders.length}
        totalRevenue={store.todayRevenue}
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        onOpenCash={() => setCashModalOpen(true)}
        onOpenDispatch={() => setDispatchModalOpen(true)}
        onOpenAttendance={() => setAttendanceModalOpen(true)}
        onOpenExpenses={() => setExpenseModalOpen(true)}
        onOpenSalesLog={() => setSalesLogOpen(true)}
        onNewDay={handleNewDay}
      />

      {/* Main Content */}
      <div className="flex flex-1 pt-[52px] overflow-hidden">
        {/* Sidebar */}
        <Sidebar
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          tables={store.tables}
          selectedTable={store.selectedTable}
          onSelectTable={store.selectTable}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
          orderType={store.orderType}
        />

        {/* Menu Grid */}
        <MenuGrid
          selectedCategory={selectedCategory}
          orderItems={store.orderItems}
          onAddItem={store.addToOrder}
        />

        {/* Order Panel */}
        <OrderPanel
          isOpen={orderPanelOpen}
          onClose={() => setOrderPanelOpen(false)}
          items={store.orderItems}
          orderType={store.orderType}
          setOrderType={store.setOrderType}
          selectedTable={store.selectedTable}
          paymentMethod={store.paymentMethod}
          setPaymentMethod={store.setPaymentMethod}
          discountValue={store.discountValue}
          setDiscountValue={store.setDiscountValue}
          discountType={store.discountType}
          setDiscountType={store.setDiscountType}
          bagQty={store.bagQty}
          setBagQty={store.setBagQty}
          bagCost={store.bagCost}
          subtotal={store.subtotal}
          bagTotal={store.bagTotal}
          discountAmount={store.discountAmount}
          tax={store.tax}
          grandTotal={store.grandTotal}
          onUpdateQty={store.updateQty}
          onRemoveItem={store.removeItem}
          onClearOrder={store.clearOrder}
          onCharge={handleCharge}
        />
      </div>

      {/* Mobile FAB - Order Button */}
      <button
        onClick={() => setOrderPanelOpen(true)}
        className="lg:hidden fixed bottom-5 right-5 z-30 w-14 h-14 rounded-2xl
        bg-gradient-to-br from-gold-500 to-gold-600 text-navy-900
        flex items-center justify-center shadow-xl shadow-gold-900/30
        hover:from-gold-400 hover:to-gold-500 active:scale-95 transition-all duration-300"
        style={{ animation: store.orderItems.length > 0 ? 'pulse-gold 2s infinite' : 'none' }}
      >
        <ShoppingCart size={22} />
        {store.orderItems.length > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-maroon-600 text-white text-[10px] font-mono font-bold flex items-center justify-center">
            {store.orderItems.reduce((s, i) => s + i.qty, 0)}
          </span>
        )}
      </button>

      {/* Modals */}
      <ChargeModal
        isOpen={chargeModalOpen}
        onClose={() => setChargeModalOpen(false)}
        items={store.orderItems}
        subtotal={store.subtotal}
        bagTotal={store.bagTotal}
        discountAmount={store.discountAmount}
        tax={store.tax}
        grandTotal={store.grandTotal}
        paymentMethod={store.paymentMethod}
        onConfirm={handleConfirmPayment}
      />

      <ReceiptModal
        isOpen={!!receiptOrder}
        onClose={() => setReceiptOrder(null)}
        order={receiptOrder}
      />

      <SalesLog
        isOpen={salesLogOpen}
        onClose={() => setSalesLogOpen(false)}
        orders={store.orders}
        onViewReceipt={(order) => { setSalesLogOpen(false); setReceiptOrder(order); }}
      />

      <CashManagement
        isOpen={cashModalOpen}
        onClose={() => setCashModalOpen(false)}
        cashTally={store.cashTally}
        onSetOpening={store.setOpeningCash}
        onSetClosing={store.setClosingCash}
        onRequestUnlock={handleUnlockCash}
        todayRevenue={store.todayRevenue}
      />

      <DispatchModal
        isOpen={dispatchModalOpen}
        onClose={() => setDispatchModalOpen(false)}
        dispatches={store.dispatches}
        onAddDispatch={store.addDispatch}
        onMarkDelivered={store.markDelivered}
      />

      <AttendanceModal
        isOpen={attendanceModalOpen}
        onClose={() => setAttendanceModalOpen(false)}
        employees={store.employees}
        attendance={store.attendance}
        onMarkAttendance={store.markAttendance}
        onAddEmployee={store.addEmployee}
        onRemoveEmployee={store.removeEmployee}
      />

      <ExpenseTracker
        isOpen={expenseModalOpen}
        onClose={() => setExpenseModalOpen(false)}
        expenses={store.expenses}
        todayRevenue={store.todayRevenue}
        onAddExpense={store.addExpense}
        onRemoveExpense={store.removeExpense}
      />

      <ManagerAuth
        isOpen={managerAuthOpen}
        onClose={() => { setManagerAuthOpen(false); setPendingAction(null); }}
        onSuccess={handleAuthSuccess}
        title={authTitle}
      />
    </div>
  );
}
